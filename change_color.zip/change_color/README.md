# change_color

You can change your display's color!
this is my firstApp made by flutter.

# how to use

if you push "TEMPLATE" button, you can choose color and display on the screen.
if you want other colors, please comment in my GooglePlayStore page. 

if you push "SET COLOR" button, you set RGB value by bar or hands.
 
